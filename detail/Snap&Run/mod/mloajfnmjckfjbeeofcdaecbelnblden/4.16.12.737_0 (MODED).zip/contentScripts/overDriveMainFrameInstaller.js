(function(){document.documentElement.setAttribute("dji-sru-fullscreen-popup","")})();
